"""Issue-to-patch workflow. The LLM proposes a patch; validation and application are explicit."""
from __future__ import annotations
from pathlib import Path
import subprocess, time
from .repository import list_files, read_text_file, python_symbols
from .sandbox import run_tests
from .llm import MockChatModel
from .patching import validate_patch, apply_patch

class SWEAgent:
    def __init__(self, model=None):
        self.model = model or MockChatModel()
    def inspect(self, workspace: str | Path) -> dict:
        files = list_files(workspace)
        py = [f for f in files if f.endswith(".py")][:40]
        symbols = {}
        for name in py:
            try: symbols[name] = python_symbols(read_text_file(workspace,name))
            except (OSError, ValueError): pass
        return {"files":files,"python_symbols":symbols}
    def plan(self, issue: str, inspection: dict) -> str:
        summary = "\n".join(inspection["files"][:100])
        return self.model.complete(f"Software issue:\n{issue}\nRepository files:\n{summary}\n"
                                   "Return a concise, evidence-based repair plan.")
    def solve(self, workspace: str | Path, issue: str, patch: str | None = None,
              apply: bool = False, docker_tests: bool = False) -> dict:
        start = time.perf_counter()
        inspection = self.inspect(workspace)
        plan = self.plan(issue, inspection)
        report = {"issue":issue,"plan":plan,"files_inspected":len(inspection["files"]),
                  "patch_supplied":bool(patch),"patch_valid":None,"patch_applied":False}
        if patch:
            valid, message = validate_patch(workspace, patch)
            report.update({"patch_valid":valid,"patch_validation_message":message})
            if valid and apply:
                apply_patch(workspace, patch); report["patch_applied"] = True
        report["tests"] = run_tests(workspace, docker=docker_tests)
        report["execution_seconds"] = time.perf_counter()-start
        report["git_diff"] = subprocess.run(["git","diff","--"],cwd=workspace,
            text=True,capture_output=True).stdout[-20000:]
        report["success"] = report["tests"]["returncode"] == 0 and (not patch or report["patch_valid"])
        return report
