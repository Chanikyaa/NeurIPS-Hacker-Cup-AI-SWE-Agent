"""LLM interface with offline deterministic implementation."""
from __future__ import annotations
import os, requests
from typing import Protocol

class ChatModel(Protocol):
    def complete(self, prompt: str) -> str: ...

class MockChatModel:
    def complete(self, prompt: str) -> str:
        # Explicitly conservative demo behavior: no invented code changes.
        return "PLAN: inspect issue-relevant files, reproduce failure, make the smallest fix, run tests."

class OpenAICompatibleChatModel:
    def __init__(self, model=None, base_url=None, api_key=None):
        self.model = model or os.getenv("OPENAI_MODEL", "gpt-4o-mini")
        self.base_url = (base_url or os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1")).rstrip("/")
        self.api_key = api_key or os.getenv("OPENAI_API_KEY", "")
    def complete(self, prompt: str) -> str:
        if not self.api_key: raise RuntimeError("OPENAI_API_KEY is required.")
        r = requests.post(self.base_url+"/chat/completions",
            headers={"Authorization":f"Bearer {self.api_key}"},
            json={"model":self.model,"messages":[{"role":"user","content":prompt}],"temperature":0},
            timeout=90)
        r.raise_for_status()
        return r.json()["choices"][0]["message"]["content"]
