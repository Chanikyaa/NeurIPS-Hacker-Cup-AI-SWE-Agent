"""Read-only repository inspection helpers."""
from pathlib import Path
import ast

IGNORED = {".git", ".venv", "venv", "__pycache__", "node_modules", ".tox"}

def list_files(root: str | Path, limit: int = 300) -> list[str]:
    root = Path(root).resolve()
    result = []
    for path in root.rglob("*"):
        if any(part in IGNORED for part in path.parts): continue
        if path.is_file() and len(result) < limit:
            result.append(str(path.relative_to(root)))
    return sorted(result)

def read_text_file(root: str | Path, relative_path: str, max_chars: int = 20000) -> str:
    root = Path(root).resolve()
    target = (root / relative_path).resolve()
    if root not in target.parents and target != root:
        raise ValueError("Path escapes repository root.")
    if not target.is_file(): raise FileNotFoundError(relative_path)
    return target.read_text(encoding="utf-8", errors="replace")[:max_chars]

def python_symbols(source: str) -> list[dict]:
    try: tree = ast.parse(source)
    except SyntaxError as exc: return [{"kind":"syntax_error","name":str(exc)}]
    return [{"kind":type(node).__name__.lower(),"name":node.name,"line":node.lineno}
            for node in ast.walk(tree) if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))]
