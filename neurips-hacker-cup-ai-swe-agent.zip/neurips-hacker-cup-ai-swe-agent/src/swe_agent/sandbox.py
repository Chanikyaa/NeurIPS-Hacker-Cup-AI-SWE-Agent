"""Constrained test execution. Docker mode is recommended for untrusted repositories."""
from __future__ import annotations
import subprocess
from pathlib import Path

def run_tests(workspace: str | Path, timeout: int = 120, docker: bool = False) -> dict:
    root = Path(workspace).resolve()
    if not root.is_dir(): raise ValueError("Workspace must be an existing directory.")
    if docker:
        command = ["docker","run","--rm","--network=none","--cpus=1","--memory=1g",
                   "-v",f"{root}:/workspace:rw","-w","/workspace","python:3.11-slim",
                   "sh","-lc","python -m pip install -q pytest && python -m pytest -q"]
    else:
        command = ["python","-m","pytest","-q"]
    try:
        result = subprocess.run(command, cwd=None if docker else root, capture_output=True,
                                text=True, timeout=timeout, check=False)
        return {"returncode":result.returncode,"stdout":result.stdout[-12000:],
                "stderr":result.stderr[-12000:],"command":command,"timed_out":False}
    except subprocess.TimeoutExpired as exc:
        return {"returncode":124,"stdout":str(exc.stdout or "")[-4000:],
                "stderr":str(exc.stderr or "")[-4000:],"command":command,"timed_out":True}
