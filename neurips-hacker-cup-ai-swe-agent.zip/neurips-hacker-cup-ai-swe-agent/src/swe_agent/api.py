from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from .agent import SWEAgent

app=FastAPI(title="SWE Agent API",version="0.1.0")
class Task(BaseModel):
    workspace: str
    issue: str
@app.post("/inspect")
def inspect(task: Task):
    try: return SWEAgent().inspect(task.workspace)
    except Exception as exc: raise HTTPException(400,str(exc)) from exc
@app.post("/plan")
def plan(task: Task):
    agent=SWEAgent()
    return {"plan":agent.plan(task.issue,agent.inspect(task.workspace))}
