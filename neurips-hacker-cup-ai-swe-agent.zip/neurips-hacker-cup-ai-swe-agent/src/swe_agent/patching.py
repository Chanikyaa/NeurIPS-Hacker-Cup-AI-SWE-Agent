"""Patch validation and application; application is restricted to the workspace."""
from pathlib import Path
import subprocess

def validate_patch(workspace: str | Path, patch_text: str) -> tuple[bool,str]:
    root = Path(workspace).resolve()
    proc = subprocess.run(["git","apply","--check","-"], cwd=root, input=patch_text,
                          text=True, capture_output=True, check=False)
    return proc.returncode == 0, proc.stderr.strip() or proc.stdout.strip()

def apply_patch(workspace: str | Path, patch_text: str) -> None:
    root = Path(workspace).resolve()
    ok, message = validate_patch(root, patch_text)
    if not ok: raise ValueError(f"Patch validation failed: {message}")
    subprocess.run(["git","apply","-"], cwd=root, input=patch_text, text=True, check=True)
