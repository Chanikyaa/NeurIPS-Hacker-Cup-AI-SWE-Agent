import argparse, json
from pathlib import Path
from .agent import SWEAgent
from .llm import MockChatModel, OpenAICompatibleChatModel

def main():
    p=argparse.ArgumentParser(description="Research-inspired, guarded SWE agent")
    p.add_argument("--repo", required=True, help="Existing local repository/workspace")
    p.add_argument("--issue", required=True)
    p.add_argument("--patch", help="Unified diff file to validate/apply")
    p.add_argument("--apply", action="store_true", help="Apply a valid patch to the workspace")
    p.add_argument("--docker-tests", action="store_true", help="Run pytest in network-disabled Docker")
    p.add_argument("--openai", action="store_true")
    p.add_argument("--output", default="swe-report.json")
    a=p.parse_args()
    patch=Path(a.patch).read_text() if a.patch else None
    model=OpenAICompatibleChatModel() if a.openai else MockChatModel()
    report=SWEAgent(model).solve(a.repo,a.issue,patch,a.apply,a.docker_tests)
    Path(a.output).write_text(json.dumps(report,indent=2),encoding="utf-8")
    print(json.dumps(report,indent=2))
if __name__=="__main__": main()
