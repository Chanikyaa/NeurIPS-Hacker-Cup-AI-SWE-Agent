# Architecture

A guarded agent workflow for repository issue triage, patching and test execution.

The application separates domain logic, provider integrations, interfaces, and persistence.
Provider-specific code is isolated behind small interfaces so deterministic local tests do not
need external services.
