See README for CLI and API startup. Docker is optional for trusted workspaces and recommended for untrusted repository tests.
