# Evaluation methodology

The benchmark runner records task count, test exit status, elapsed wall time and a one-step
iteration count for its deliberately small example suite. Issue resolution rate should be computed
only when an independent evaluator confirms that the patch satisfies the issue, not merely because
tests pass. Patch validity means `git apply --check` succeeds. Token usage is unavailable for the
offline mock and is not fabricated. Expand evaluation with held-out issue sets, hidden tests,
human patch review, repeated runs and model-reported token usage.

## Safety boundary
The default mode runs pytest directly in the current workspace and is suitable only for trusted
code. `--docker-tests` uses a disposable Docker container with no network, CPU/memory limits and
a mounted workspace. Docker daemon availability and host/container escape risks remain operational
concerns. Review every patch. The tool never clones arbitrary URLs or executes model-proposed shell
commands. Patch application requires both a valid supplied diff and explicit `--apply`.
