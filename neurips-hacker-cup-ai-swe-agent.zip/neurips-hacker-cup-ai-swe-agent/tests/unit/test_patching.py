import subprocess
from swe_agent.patching import validate_patch

def test_patch_check(tmp_path):
    subprocess.run(["git","init"],cwd=tmp_path,check=True,capture_output=True)
    f=tmp_path/"a.txt"; f.write_text("old\n")
    subprocess.run(["git","add","a.txt"],cwd=tmp_path,check=True)
    subprocess.run(["git","-c","user.email=a@b.c","-c","user.name=test","commit","-m","init"],
                   cwd=tmp_path,check=True,capture_output=True)
    patch="--- a/a.txt\n+++ b/a.txt\n@@ -1 +1 @@\n-old\n+new\n"
    assert validate_patch(tmp_path,patch)[0]
