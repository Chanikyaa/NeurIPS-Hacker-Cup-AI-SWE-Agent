from swe_agent.agent import SWEAgent

def test_plan_and_test_report(tmp_path):
    (tmp_path/"test_demo.py").write_text("def test_ok(): assert 1 == 1\n")
    report=SWEAgent().solve(tmp_path,"Tests should pass")
    assert report["files_inspected"] >= 1
    assert report["tests"]["returncode"] == 0
