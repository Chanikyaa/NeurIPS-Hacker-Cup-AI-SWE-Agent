from swe_agent.repository import list_files, read_text_file, python_symbols
import pytest

def test_inspection(tmp_path):
    (tmp_path/"sample.py").write_text("class A:\n def run(self): pass\n")
    assert "sample.py" in list_files(tmp_path)
    assert python_symbols(read_text_file(tmp_path,"sample.py"))[0]["name"] == "A"

def test_path_traversal_blocked(tmp_path):
    with pytest.raises(ValueError): read_text_file(tmp_path,"../secret")
