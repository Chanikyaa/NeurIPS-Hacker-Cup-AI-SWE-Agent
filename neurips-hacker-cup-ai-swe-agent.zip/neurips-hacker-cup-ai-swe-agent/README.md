# NeurIPS Hacker Cup AI – SWE Agent (research-inspired)

An independent software-engineering agent scaffold that inspects a local repository, turns a
GitHub-style issue into a plan, validates a supplied unified diff, optionally applies it, runs
tests and writes an execution report. This is **not an official competition submission**, and no
participation, ranking, or compliance is claimed.

## Problem and motivation
Issue resolution requires repository navigation, code understanding, controlled edits and
regression validation. This project separates these stages and makes patch application an explicit
reviewable action.

## Features
- Repository file inventory and Python AST symbol extraction.
- Planner abstraction with offline mock and OpenAI-compatible API.
- Workspace path traversal protection for file reads.
- Unified-diff validation via `git apply --check`.
- Explicit opt-in patch application and pytest execution.
- Optional network-disabled Docker test execution.
- FastAPI inspection/planning endpoints and JSON reports.

## Architecture
```mermaid
flowchart TD
 I[Issue report] --> P[Planner]
 R[Local repository] --> X[Repository explorer / AST]
 X --> P
 P --> C[Patch supplied by reviewer or coder]
 C --> V[git apply --check]
 V -->|approved with --apply| A[Workspace patch]
 V --> T[pytest executor]
 A --> T
 T --> O[Execution report + git diff]
```

## Stack
Python, AST, Git CLI, pytest, Docker, Pydantic, FastAPI, Requests.

## Install and run
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
pip install -e .
python -m swe_agent.cli --repo /path/to/repo --issue "Parser fails on empty input"
```
Validate a patch without applying it:
```bash
python -m swe_agent.cli --repo /path/to/repo --issue "Fix parser" --patch fix.patch
```
Apply only after review:
```bash
python -m swe_agent.cli --repo /path/to/repo --issue "Fix parser" --patch fix.patch --apply --docker-tests
```
Start API: `uvicorn swe_agent.api:app --app-dir src --reload`.

## Demo
Use a disposable Git repository with a pytest suite and a reviewed unified diff. The offline planner
returns a generic plan and does not autonomously author code. The report contains actual test output,
patch validity, elapsed time and a git diff. No resolution-rate claims are made.

## Evaluation
See [docs/methodology.md](docs/methodology.md). The included benchmark is a harness fixture, not a
validated SWE-bench-style score.

## Limitations
- The default mock planner does not generate patches.
- The supplied patch must be created/reviewed externally; model-generated patch orchestration is a
  future extension.
- Direct test execution is unsafe for untrusted code; use isolated Docker and review container
  configuration.
- No automatic GitHub cloning, issue posting, or host shell-agent loop is enabled.

## Future improvements
Add a permissioned tool loop, AST-aware edit proposals, hidden-test evaluation, container image
hardening, token/cost instrumentation, repository snapshots and human review UI.

## Contributing and security
See [CONTRIBUTING.md](CONTRIBUTING.md) and [SECURITY.md](SECURITY.md). MIT license.

GitHub topics: `swe-agent`, `software-engineering`, `code-repair`, `agents`, `pytest`.
