"""Small reproducible harness over example workspaces; reports actual run outcomes only."""
import json, sys
from pathlib import Path
from swe_agent.agent import SWEAgent
root=Path(sys.argv[1] if len(sys.argv)>1 else ".").resolve()
tasks=json.loads(Path("examples/benchmark.json").read_text())
rows=[]
for task in tasks:
    result=SWEAgent().solve(root,task["issue"])
    rows.append({"id":task["id"],"tests_passed":result["tests"]["returncode"]==0,
                 "execution_seconds":result["execution_seconds"],"iterations":1})
print(json.dumps({"task_count":len(rows),"results":rows},indent=2))
